import PySimpleGUI as sg
window = sg.Window(title="Profile", layout=[
    [sg.Text("NPM      : 2210010559 ")],
    [sg.Text("Nama     : M.Rizqi Rizaldi ")],
    [sg.Text("Kelas     : 5N Regular Banjarmasin ")],
    [sg.Text("Matkul    : Pemograman Visual 3 ")],
    
    ],size=(400,200))
window()
window.close()